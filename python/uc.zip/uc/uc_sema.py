import argparse
import pathlib
import sys
from copy import deepcopy
from typing import Any, Dict, Union
from uc.uc_ast import Return, Compound, If, FuncDecl, ID, ExprList, Constant, ArrayRef, ArrayDecl, InitList
from uc.uc_parser import UCParser
from uc.uc_type import CharType, IntType, BoolType, StringType, FuncType, VoidType, ArrayType

class SymbolTable:
    """Class representing a symbol table.

    `add` and `lookup` methods are given, however you still need to find a way to
    deal with scopes.

    ## Attributes
    - :attr data: the content of the SymbolTable
    """

    def __init__(self):
        self.__data = []

    __data = []

    def get(self):
        return self.__data

    def create_scope(self):
        self.__data.append({})

    def remove_scope(self):
        self.__data.pop()

    @property
    def data(self) -> Dict[str, Any]:
        """ Returns a copy of the SymbolTable.
        """
        return deepcopy(self.__data)

    def add(self, name: str, value: Any) -> None:
        """ Adds to the SymbolTable.

        ## Parameters
        - :param name: the identifier on the SymbolTable
        - :param value: the value to assign to the given `name`
        """
        self.__data[-1][name] = value
        if len(self.__data) > 1 and isinstance(value, FuncType):
            self.__data[0][name] = value
    def lookup(self, name: str) -> Union[Any, None]:
        """ Searches `name` on the SymbolTable and returns the value
        assigned to it.

        ## Parameters
        - :param name: the identifier that will be searched on the SymbolTable

        ## Return
        - :return: the value assigned to `name` on the SymbolTable. If `name` is not found, `None` is returned.
        """
        for scope in self.__data[::-1]:
            if name in scope:
                return scope[name]
        return None

    def exists_in_scope(self, name: str):
        return name in self.__data[-1]

    def get_scope_function_return_type(self):
        for item in self.__data[::-1]:
            for k, v in item.items():
                if isinstance(v, FuncType):
                    return v.type
        return VoidType

    def add_scope_return(self):
        has_return = False
        for i in range(len(self.__data)):
            for k, v in self.__data[len(self.__data) - i - 1].items():
                if isinstance(v, FuncType):
                    has_return = True
                    break
        if has_return:
            self.__data[len(self.__data) - 1]["return"] = BoolType
    def is_inside_loop(self):
        # -1 because we don't need to check global scope
        for i in range(len(self.__data) - 1):
            for k, v in self.__data[len(self.__data) - i - 1].items():
                if k == "loop":
                    return True
        return False

    def scope_has_return(self):
        return "return" in self.__data[-1]


class NodeVisitor:
    """A base NodeVisitor class for visiting uc_ast nodes.
    Subclass it and define your own visit_XXX methods, where
    XXX is the class name you want to visit with these
    methods.
    """

    _method_cache = None

    def generic_visit(self, node):
        """Called if no explicit visitor function exists for a
        node. Implements preorder visiting of the node.
        """
        for _, child in node.children():
            self.visit(child)

    def visit(self, node):
        """Visit a node."""

        if self._method_cache is None:
            self._method_cache = {}

        visitor = self._method_cache.get(node.__class__.__name__)
        if visitor is None:
            method = "visit_" + node.__class__.__name__
            visitor = getattr(self, method, self.generic_visit)
            self._method_cache[node.__class__.__name__] = visitor

        return visitor(node)


class Visitor(NodeVisitor):
    """
    Program visitor class. This class uses the visitor pattern. You need to define methods
    of the form visit_NodeName() for each kind of AST node that you want to process.
    """

    def __init__(self):
        # Initialize the symbol table
        self.symtab = SymbolTable()
        self.typemap = {
            "int": IntType,
            "char": CharType,
            "bool": BoolType,
            "string": StringType,
            "void": VoidType,
            "function": FuncType
        }

    def _assert_semantic(self, condition: bool, msg_code: int, coord, name: str = "", ltype="", rtype=""):
        """Check condition, if false print selected error message and exit"""
        error_msgs = {
            1: f"{name} is not defined",
            2: f"subscript must be of type(int), not {ltype}",
            3: "Expression must be of type(bool)",
            4: f"Cannot assign {rtype} to {ltype}",
            5: f"Binary operator {name} does not have matching LHS/RHS types",
            6: f"Binary operator {name} is not supported by {ltype}",
            7: "Break statement must be inside a loop",
            8: "Array dimension mismatch",
            9: f"Size mismatch on {name} initialization",
            10: f"{name} initialization type mismatch",
            11: f"{name} initialization must be a single element",
            12: "Lists have different sizes",
            13: "List & variable have different sizes",
            14: f"conditional expression is {ltype}, not type(bool)",
            15: f"{name} is not a function",
            16: f"no. arguments to call {name} function mismatch",
            17: f"Type mismatch with parameter {name}",
            18: "The condition expression must be of type(bool)",
            19: "Expression must be a constant",
            20: "Expression is not of basic type",
            21: f"{name} does not reference a variable of basic type",
            22: f"{name} is not a variable",
            23: f"Return of {ltype} is incompatible with {rtype} function definition",
            24: f"Name {name} is already defined in this scope",
            25: f"Unary operator {name} is not supported",
        }
        if not condition:
            msg = error_msgs[msg_code]  # invalid msg_code raises Exception
            print("SemanticError: %s %s" % (msg, coord), file=sys.stdout)
            sys.exit(1)

    def _FuncDef_check_return_type(self, func_type, node):
        """ Check, recursively, if Return nodes in FuncDef are the same type as the func"""
        if hasattr(node, "staments"):
            for statement in node.staments:
                if isinstance(statement, Compound):
                    self._FuncDef_check_return_type(func_type, statement)
                if isinstance(statement, If):
                    self._FuncDef_check_return_type(func_type, statement.iftrue)
                    if statement.iffalse:
                        self._FuncDef_check_return_type(func_type, statement.iffalse)
                if isinstance(statement, Return):
                    self._assert_semantic(func_type == statement.uc_type, 23, statement.coord,
                                          ltype=f"type({statement.uc_type.typename})",
                                          rtype=f"type({func_type.typename})")

    def visit_Assert(self, node):
        self.visit(node.expr)
        self._assert_semantic(node.expr.uc_type.typename == "bool", 3, node.expr.coord)
        node.uc_type = node.expr.uc_type

    def visit_Assignment(self, node):
        # visit right side
        self.visit(node.rvalue)
        rtype = self._get_assignment_basic_type(node.rvalue.uc_type)
        # visit left side (must be a location)
        _var = node.lvalue
        self.visit(_var)
        ltype = self._get_assignment_basic_type(node.lvalue.uc_type)
        # Check that assignment is allowed
        self._assert_semantic(ltype == rtype, 4, node.coord,
                              ltype=f"type({ltype.typename})", rtype=f"type({rtype.typename})")
        # Check that assign_ops is supported by the type
        self._assert_semantic(
            node.op in ltype.assign_ops, 5, node.coord, name=node.op, ltype=ltype
        )

    def _get_assignment_basic_type(self, type):
        if isinstance(type, ArrayType):
            return self._get_assignment_basic_type(type.type)
        else:
            return type

    def visit_BinaryOp(self, node):
        # Visit the left and right expression
        self.visit(node.lvalue)
        ltype = node.lvalue.uc_type
        if isinstance(node.lvalue, ArrayRef):
            ltype = node.lvalue.uc_type.type
        self.visit(node.rvalue)
        rtype = node.rvalue.uc_type
        if isinstance(node.rvalue, ArrayRef):
            rtype = node.rvalue.uc_type.type
        self._assert_semantic(ltype == rtype, 5, node.coord,
                              name=node.op, ltype=ltype, rtype=rtype)
        self._assert_semantic(node.op in ltype.binary_ops or node.op in ltype.rel_ops, 6, node.coord,
                              name=node.op, ltype=f"type({ltype.typename})")
        node.uc_type = ltype if node.op in ltype.binary_ops else self.typemap['bool']

    def visit_Break(self, node):
        self._assert_semantic(self.symtab.is_inside_loop(), 7, node.coord)
    def visit_Compound(self, node):
        # initially, set type as "void"
        node.uc_type = self.typemap['void']

        # visit every statement, if a return is found, update the uc_type. This
        # might result in an issue where there are two returns in a function, but
        # they have different types. We can figure how to sort this out later.
        for statement in node.staments:
            if isinstance(statement, Compound):
                self.symtab.create_scope()
            self.visit(statement)
            if isinstance(statement, Compound):
                self.symtab.remove_scope()
            if isinstance(statement, Return):
                node.uc_type = statement.uc_type

    def visit_Constant(self, node):
        node.uc_type = self.typemap[node.type]

    def visit_Decl(self, node):
        self.visit(node.type)
        if isinstance(node.type, ArrayDecl):
            dimension = 0
            if node.type.dim is not None:
                dimension = node.type.dim.value
            self._assert_semantic(self._is_array_dimension_mismatch(node.type, dimension), 8, node.name.coord)
        if node.init:
            self.visit(node.init)
            ltype = node.type.uc_type
            rtype = node.init.uc_type
            if isinstance(ltype, ArrayType):
                if node.type.dim is not None and isinstance(node.init, Constant):
                    self._assert_semantic(node.type.dim.value == len(node.init.value), 9, node.name.coord, name=node.name.name)
                elif node.type.dim is not None:
                    self._assert_semantic(self._get_array_decl_dimensions(node.type, []) == self._get_init_list_dimensions(node.name, node.init, []), 13, node.name.coord)
            if isinstance(rtype, ArrayType):
                self._assert_semantic(isinstance(ltype, ArrayType), 11, node.name.coord,
                                      name=node.name.name)
            elif not (isinstance(ltype, ArrayType) and ltype.type.typename == "char" and rtype.typename == "string"):
                self._assert_semantic(ltype == rtype, 10, node.name.coord,
                                      name=node.name.name)
        self._assert_semantic(not self.symtab.exists_in_scope(node.name.name), 24,
                              node.name.coord, name=node.name.name)
        self.symtab.add(node.name.name, node.type.uc_type)


    def _get_array_decl_dimensions(self, node, dimensions):
        dimensions.append(int(node.dim.value))
        if hasattr(node, "type") and hasattr(node.type, "dim"):
            return self._get_array_decl_dimensions(node.type, dimensions)
        return dimensions

    def _get_init_list_dimensions(self, name, node, dimensions):
        if isinstance(node.exprs[0], Constant) and len(dimensions) == 0:
            dimensions.append(len(node.exprs))
        else:
            dimensions.append(len(node.exprs))
            if not isinstance(node.exprs[0], Constant):
                list_size = len(node.exprs[0].exprs)
                for expression in node.exprs:
                    self._assert_semantic(len(expression.exprs) == list_size, 12, name.coord)
                return self._get_init_list_dimensions(name, node.exprs[0], dimensions)
        return dimensions


    def _is_array_dimension_mismatch(self, node, size):
        dimension = 0
        if node.dim is not None:
            dimension = node.dim.value
        if dimension != size:
            return False
        if isinstance(node.type, ArrayDecl):
            return self._is_array_dimension_mismatch(node.type, size)
        return True
    def visit_ArrayDecl(self, node):
        self.visit(node.type)
        node.uc_type = ArrayType(node.type.uc_type)
        if node.dim is not None:
            self.visit(node.dim)

    def visit_ArrayRef(self, node):
        self.visit(node.name)
        node.uc_type = node.name.uc_type
        self.visit(node.subscript)
        self._assert_semantic(node.subscript.uc_type.typename == "int", 2,
                              node.subscript.coord, ltype=f"type({node.subscript.uc_type.typename})")
    def visit_ExprList(self, node):
        for expression in node.exprs:
            self.visit(expression)

    def visit_For(self, node):
        self.symtab.create_scope()
        self.symtab.add("loop", BoolType)
        self.visit(node.init)
        self.visit(node.cond)
        self.visit(node.next)
        self.visit(node.body)
        self.symtab.remove_scope()

    def visit_FuncCall(self, node):
        self.visit(node.name)
        self._assert_semantic(isinstance(node.name.uc_type, FuncType), 15, node.name.coord,
                              name=node.name.name)
        node.uc_type = self.typemap[node.name.uc_type.type.typename]
        if node.args is not None:
            self.visit(node.args)
            function_type = self.symtab.lookup(node.name.name)
            if hasattr(node.args, "exprs"):
                self._assert_semantic(len(function_type.params.params) == len(node.args.exprs), 16, node.coord,
                                      name=node.name.name)
                for i in range(len(function_type.params.params)):
                    declared_param = function_type.params.params[i]
                    call_param = node.args.exprs[i]
                    self._assert_semantic(declared_param.type.uc_type == call_param.uc_type, 17, call_param.coord,
                                          name=declared_param.name.name)
            else:
                self._assert_semantic(len(function_type.params.params) == 1, 16, node.coord,
                                      name=node.name.name)
                declared_param = function_type.params.params[0]
                call_param = node.args
                self._assert_semantic(declared_param.type.uc_type == call_param.uc_type, 17, call_param.coord,
                                      name=declared_param.name.name)
    def visit_FuncDecl(self, node):
        self.visit(node.type)
        if node.params:  # if FuncDecl has params in its definition
            self.visit(node.params)
        node.uc_type = FuncType(node.type.uc_type, node.params)

    def visit_FuncDef(self, node):
        self.symtab.create_scope()
        self.visit(node.type)  # visit type of the function definition
        self.visit(node.decl)  # visit function declaration
        self.visit(node.body)  # visit body (compound) node to set a type to it
        # check one more time with the Compound type, just in case no return is present
        if not self.symtab.scope_has_return():
            self._assert_semantic(node.body.uc_type == node.type.uc_type, 23, node.body.coord,
                                  ltype=f"type({node.body.uc_type.typename})", rtype=f"type({node.type.uc_type.typename})")
        self.symtab.remove_scope()

    def visit_ID(self, node):
        self._assert_semantic(self.symtab.lookup(node.name) is not None,
                              1, node.coord, name=node.name)

        node.uc_type = self.symtab.lookup(node.name)

    def visit_If(self, node):
        self.visit(node.cond)
        condition = VoidType
        if hasattr(node.cond, "uc_type"):
            condition = node.cond.uc_type
        self._assert_semantic(condition.typename == 'bool', 18, node.cond.coord)
        self.visit(node.iftrue)
        if node.iffalse:
            self.visit(node.iffalse)

        node.uc_type = node.cond.uc_type

    def visit_InitList(self, node):
        for expression in node.exprs:
            self.visit(expression)
            if not isinstance(expression, InitList):
                self._assert_semantic(isinstance(expression, Constant), 19, expression.coord)
        node.uc_type = ArrayType(node.exprs[0].uc_type)

    def visit_ParamList(self, node):
        for param in node.params:
            self.visit(param)

    def visit_Print(self, node):
        if node.expr is not None:
            self.visit(node.expr)
            if isinstance(node.expr, ExprList):
                for expression in node.expr.exprs:
                    self._assert_basic_type(expression)
            else:
                self._assert_basic_type(node.expr)
    def _assert_basic_type(self, expression):
        type = expression.uc_type
        if isinstance(expression, ArrayRef):
            while isinstance(type, ArrayType):
                type = type.type
        if isinstance(expression, ID):
            self._assert_semantic(type.is_basic_type, 21, expression.coord, name=expression.name)
        else:
            self._assert_semantic(type.is_basic_type, 20, expression.coord)
    def visit_Program(self, node):
        # Visit all of the global declarations
        self.symtab.create_scope()
        for _decl in node.gdecls:
            self.visit(_decl)

    def visit_Read(self, node):
        if isinstance(node.names, ExprList): # check if has multiple arguments
            for name in node.names.exprs:
                self._assert_semantic(isinstance(name, ID) or isinstance(name, ArrayRef), 22, name.coord,
                                      name=name.name)
                self.visit(name)
        else:
            self._assert_semantic(isinstance(node.names, ID) or isinstance(node.names, ArrayRef), 22, node.names.coord,
                                  name=node.names)
            self.visit(node.names)

    def visit_Return(self, node):
        return_type = self.symtab.get_scope_function_return_type()
        if node.expr is None:
            self._assert_semantic(VoidType == return_type, 23, node.coord,
                                  ltype=f"type({VoidType})", rtype=f"type({return_type.typename})")
            node.uc_type = VoidType
        else:
            self.visit(node.expr)
            node.uc_type = node.expr.uc_type
            self._assert_semantic(node.uc_type == return_type, 23, node.coord,
                                  ltype=f"type({node.uc_type.typename})", rtype=f"type({return_type.typename})")
        self.symtab.add_scope_return()

    def visit_Type(self, node):
        node.uc_type = self.typemap[node.name]

    def visit_UnaryOp(self, node):
        self.visit(node.expr)
        type = node.expr.uc_type

        self._assert_semantic(node.op in type.unary_ops, 25, node.coord, name=node.op)
        node.uc_type = type

    def visit_VarDecl(self, node):
        self.visit(node.type)
        node.uc_type = node.type.uc_type

    def visit_While(self, node):
        self.symtab.create_scope()
        self.symtab.add("loop", BoolType)
        self.visit(node.cond)
        self._assert_semantic(node.cond.uc_type.typename == "bool", 14, node.coord,
                              ltype=f"type({node.cond.uc_type.typename})")
        self.visit(node.body)
        self.symtab.remove_scope()


if __name__ == "__main__":
    # create argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "input_file", help="Path to file to be semantically checked", type=str
    )
    args = parser.parse_args()

    # get input path
    input_file = args.input_file
    input_path = pathlib.Path(input_file)

    # check if file exists
    if not input_path.exists():
        print("Input", input_path, "not found", file=sys.stderr)
        sys.exit(1)

    # set error function
    p = UCParser()
    # open file and parse it
    with open(input_path) as f:
        ast = p.parse(f.read())
        ast.show(buf=sys.stdout, showcoord=True)
        sema = Visitor()
        sema.visit(ast)
