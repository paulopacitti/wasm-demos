import argparse
import pathlib
import sys
from copy import deepcopy
from typing import Dict, List, Tuple, Any, Union
from uc.uc_type import ArrayType
from uc.uc_ast import FuncDef, Node, ExprList, Constant, ArrayDecl, ArrayRef
from uc.uc_block import CFG, BasicBlock, Block, ConditionBlock, format_instruction, EmitBlocks
from uc.uc_interpreter import Interpreter
from uc.uc_parser import UCParser
from uc.uc_sema import NodeVisitor, Visitor

binary_ops = {
            "+": "add",
            "-": "sub",
            "*": "mul",
            "/": "div",
            "%": "mod",
            "<": "lt",
            "<=": "le",
            ">=":  "ge",
            ">": "gt",
            "==": "eq",
            "!=": "ne",
            "&&": "and",
            "||": "or"
}

class SymbolTable:
    """Class representing a symbol table.
        key: var name, value: register
    """

    def __init__(self):
        self.__data = []

    __data = []

    def get(self):
        return self.__data

    def create_scope(self):
        self.__data.append({})

    def remove_scope(self):
        self.__data.pop()

    @property
    def data(self) -> Dict[str, Any]:
        """ Returns a copy of the SymbolTable.
        """
        return deepcopy(self.__data)

    def add(self, name: str, value: Any) -> None:
        """ Adds to the SymbolTable.

        ## Parameters
        - :param name: the identifier on the SymbolTable
        - :param value: the value to assign to the given `name`
        """
        self.__data[-1][name] = value

    def lookup(self, name: str) -> Union[Any, None]:
        """
        Searches `name` on the SymbolTable and returns the register
        assigned to it.

        ## Parameters
        - :param name: the identifier that will be searched on the SymbolTable

        ## Return
        - :return: the value assigned to `name` on the SymbolTable. If `name` is not found, `None` is returned.
        """

        for scope in self.__data[::-1]:
            if name in scope:
                return scope[name]
        return None

class CodeGenerator(NodeVisitor):
    """
    Node visitor class that creates 3-address encoded instruction sequences
    with Basic Blocks & Control Flow Graph.
    """

    def __init__(self, viewcfg: bool):
        self.viewcfg: bool = viewcfg
        self.current_block: Block = None
        self.current_return: Block = None
        self.current_loop: Block = None
        self.symtab = SymbolTable()
        self.dimtab = {}

        # version dictionary for temporaries. We use the name as a Key
        self.fname: str = "_glob_"
        self.versions: Dict[str, int] = {self.fname: 1}

        # The generated code (list of tuples)
        # At the end of visit_program, we call each function definition to emit
        # the instructions inside basic blocks. The global instructions that
        # are stored in self.text are appended at beginning of the code
        self.code: List[Tuple[str]] = []

        self.text: List[Tuple[str]] = []  # Used for global declarations & constants (list, strings)

        # TODO: Complete if needed.

    def show(self, buf=sys.stdout):
        _str = ""
        for _code in self.code:
            _str += format_instruction(_code) + "\n"
        buf.write(_str)

    def new_temp(self) -> str:
        """
        Create a new temporary variable of a given scope (function name).
        """
        if self.fname not in self.versions:
            self.versions[self.fname] = 1
        name = "%" + "%d" % (self.versions[self.fname])
        self.versions[self.fname] += 1
        return name

    def new_var(self, varname) -> str:
        """
        Create a new varname variable of a given scope.
        """
        if varname not in self.versions:
            self.versions[varname] = 1
        name = "%" + varname + ".%d" % (self.versions[varname])
        self.versions[varname] += 1

        self.symtab.add(varname, name)
        return name

    def new_label(self, label) -> str:
        """
        Create a new varname variable of a given scope.
        """
        if label not in self.versions:
            self.versions[label] = 1
        name = "%" + label + ".%d" % (self.versions[label])
        self.versions[label] += 1
        return name

    def new_text(self, typename: str) -> str:
        """
        Create a new literal constant on global section (text).
        """
        name = "@." + typename + "." + "%d" % (self.versions["_glob_"])
        self.versions["_glob_"] += 1
        return name

    # You must implement visit_Nodename methods for all of the other
    # AST nodes.  In your code, you will need to make instructions
    # and append them to the current block code list.
    #
    # A few sample methods follow. Do not hesitate to complete or change
    # them if needed.

    def _ParamList_alloc(self, node, header):
        # alloc params
        for i in range(len(node.params)):
            self.visit(node.params[i])

        # store temps from header into params
        for i in range(len(node.params)):
            _type = node.params[i].type.uc_type.typename
            _varname = node.params[i].gen_location
            inst = ("store_" + _type, header[i][1], _varname)
            self.current_block.append(inst)

    def _ParamList_gen_header(self, node):
        # return arrays of temps of params header
        params_header = []
        for param in node.params:
            _type = param.type.uc_type.typename
            _temp = self.new_temp()
            params_header.append((_type, _temp))
        return params_header

    def visit_ArrayRef(self, node):
        if isinstance(node.name, ArrayRef):
            node.name.bidimensional = True
            self.visit(node.name)
            self.visit(node.subscript)
            _add_target = self.new_temp()
            inst = ("add_int", node.name.gen_location, node.subscript.gen_location, _add_target)
            self.current_block.append(inst)
            _elem_target = self.new_temp()
            _load_target = self.new_temp()
            _type = node.uc_type.type.type.typename
            inst = ("elem_" + _type, self.symtab.lookup(node.name.name.name), _add_target, _elem_target)
            self.current_block.append(inst)
            inst = ("load_" + _type + "_*", _elem_target, _load_target)
            self.current_block.append(inst)
            node.gen_location = _load_target
            node.arr_pos = _elem_target
        elif hasattr(node, "bidimensional"):
            _size_temp = self.new_temp()
            inst = ("literal_int", int(self.dimtab[self.symtab.lookup(node.name.name)].split("_")[-1]), _size_temp)
            _load_target = self.new_temp()
            self.current_block.append(inst)
            if isinstance(node.subscript, Constant):
                inst = ("literal_int", int(node.subscript.value), _load_target)
            else:
                inst = ("load_int", self.symtab.lookup(node.subscript.name), _load_target)
            self.current_block.append(inst)
            _mul_target = self.new_temp()
            inst = ("mul_int", _size_temp, _load_target, _mul_target)
            self.current_block.append(inst)
            node.gen_location = _mul_target
        else:
            self.visit(node.subscript)
            _elem_target = self.new_temp()
            _load_target = self.new_temp()
            _type = node.uc_type.type.typename
            inst = ("elem_" + _type, self.symtab.lookup(node.name.name), node.subscript.gen_location, _elem_target)
            self.current_block.append(inst)
            inst = ("load_" + _type + "_*", _elem_target, _load_target)
            self.current_block.append(inst)
            node.gen_location = _load_target

    def visit_Assert(self, node):
        label_assert_cond = self.new_label("assert.cond")
        label_assert_true = self.new_label("assert.true")
        label_assert_false = self.new_label("assert.false")

        # create jump to asssert.cond block
        inst = ("jump", label_assert_cond)
        self.current_block.append(inst)

        # assert.cond block
        assert_cond_block = ConditionBlock(label_assert_cond[1:])
        assert_cond_block.predecessors.append(self.current_block)
        self.current_block.next_block = assert_cond_block
        self.current_block.branch = assert_cond_block
        self.current_block = assert_cond_block

        inst = (label_assert_cond[1:] + ":",)
        self.current_block.append(inst)
        self.visit(node.expr)
        inst = ("cbranch", node.expr.gen_location, label_assert_true, label_assert_false)
        self.current_block.append(inst)

        # assert.false block
        assert_false_block = BasicBlock(label_assert_false[1:])
        inst = (label_assert_false[1:] + ":",)
        assert_false_block.append(inst)

        _target = self.new_text("str")
        if node.expr is not None:
            coord = node.expr.coord
        else:
            coord = node.coord
        error_message = "assertion_fail on " + str(coord.line) + ":" + str(coord.column)
        inst = ("global_string", _target, error_message)
        self.text.append(inst)

        inst = ("print_string", _target)
        assert_false_block.append(inst)
        inst = ("jump", "%" + self.current_return.label)
        assert_false_block.append(inst)
        assert_false_block.branch = self.current_return
        self.current_return.predecessors.append(assert_false_block)

        assert_false_block.predecessors.append(self.current_block)
        self.current_block.fall_through = assert_false_block
        self.current_block.next_block = assert_false_block

        # assert.true block
        assert_true_block = BasicBlock(label_assert_true[1:])
        assert_true_block.predecessors.append(self.current_block)
        assert_true_block.predecessors.append(assert_false_block)
        self.current_block.taken = assert_true_block
        self.current_block.fall_through.next_block = assert_true_block
        self.current_block = assert_true_block
        inst = (label_assert_true[1:] + ":",)
        self.current_block.append(inst)

    def visit_Assignment(self, node: Node):
        if isinstance(node.lvalue.uc_type, ArrayType):
            if hasattr(node.rvalue, "name") and isinstance(node.rvalue.name, ArrayRef):
                self.visit(node.rvalue)
            if isinstance(node.lvalue.name, ArrayRef):
                _typename = node.lvalue.uc_type.type.type.typename
            else:
                _typename = node.lvalue.uc_type.type.typename

            _rvalue_elem_target = self.new_temp()
            _load_target = self.new_temp()
            if isinstance(node.rvalue.uc_type, ArrayType):
                if isinstance(node.rvalue.name, ArrayRef):
                    self.visit(node.rvalue)
                    _rvalue_elem_target = node.rvalue.arr_pos
                else:
                    self.visit(node.rvalue.subscript)
                    inst = (
                    "elem_" + _typename, self.symtab.lookup(node.rvalue.name.name), node.rvalue.subscript.gen_location,
                    _rvalue_elem_target)
                    self.current_block.append(inst)
                inst = ("load_" + _typename + "_*", _rvalue_elem_target, _load_target)
                self.current_block.append(inst)
            else:
                self.visit(node.rvalue)
                inst = ("load_" + _typename, node.rvalue.gen_location, _load_target)
                self.current_block.append(inst)

            if isinstance(node.lvalue.name, ArrayRef):
                self.visit(node.lvalue)
                _lvalue_elem_target = node.lvalue.arr_pos
            else:
                _lvalue_elem_target = self.new_temp()
                self.visit(node.lvalue.subscript)
                inst = ("elem_" + _typename, self.symtab.lookup(node.lvalue.name.name), node.lvalue.subscript.gen_location,
                        _lvalue_elem_target)
                self.current_block.append(inst)
            inst = ("store_" + _typename + "_*", _load_target, _lvalue_elem_target)
            self.current_block.append(inst)
        else:
            self.visit(node.rvalue)
            _target = self.symtab.lookup(node.lvalue.name)
            inst = (
                "store_" + node.lvalue.uc_type.typename,
                node.rvalue.gen_location,
                _target,
            )
            self.current_block.append(inst)

    def visit_UnaryOp(self, node):
        self.visit(node.expr)
        if node.op == '-':
            zero_temp = self.new_temp()
            inst = ("literal_int", 0, zero_temp)
            self.current_block.append(inst)
            target = self.new_temp()
            inst = ("sub_int", zero_temp, node.expr.gen_location, target)
            self.current_block.append(inst)
            node.gen_location = target
        else:
            target = self.new_temp()
            node.gen_location = target
            inst = ("not_bool", node.expr.gen_location, target)
            self.current_block.append(inst)
    def visit_BinaryOp(self, node: Node):
        # Visit the left and right expressions
        self.visit(node.lvalue)
        self.visit(node.rvalue)

        # Make a new temporary for storing the result
        target = self.new_temp()
        _type = node.lvalue.uc_type.typename
        if isinstance(node.lvalue.uc_type, ArrayType):
            _type = node.lvalue.uc_type.type.typename
        else:
            _type = node.lvalue.uc_type.typename

        # Create the opcode and append to list
        opcode = binary_ops[node.op] + "_" + _type
        inst = (opcode, node.lvalue.gen_location, node.rvalue.gen_location, target)
        self.current_block.append(inst)

        # Store location of the result on the node
        node.gen_location = target

    def visit_Break(self, node):
        # create labels and blocks
        label_break_in = self.new_label("break.in")
        label_break_out = self.new_label("break.out")
        break_in_block = BasicBlock(label_break_in[1:])
        break_out_block = BasicBlock(label_break_out[1:])

        inst = ("jump", label_break_in)
        self.current_block.append(inst)
        self.current_block.branch = break_in_block
        self.current_block.next_block = break_in_block

        # break in block
        break_in_block.predecessors.append(self.current_block)
        self.current_block = break_in_block
        self.current_block.predecessors.append(self.current_loop)

        inst = (label_break_in[1:] + ":",)
        self.current_block.append(inst)

        _loop_exit_target = "%" + self.current_loop.label
        inst = ("jump", _loop_exit_target)
        self.current_block.append(inst)
        self.current_block.branch = self.current_loop
        self.current_loop.predecessors.append(self.current_block)
        self.current_block.next_block = break_out_block
        inst = ("jump", label_break_out)
        self.current_block.append(inst)

        # break out block (dead code)
        break_out_block.predecessors.append(self.current_block)
        inst = (label_break_out[1:] + ":",)
        break_out_block.append(inst)
        self.current_block = break_out_block


    def visit_Compound(self, node):
        for statement in node.staments:
            self.visit(statement)

    def visit_Constant(self, node: Node):
        _type = node.uc_type.typename
        if _type == "string":
            _target = self.new_text("str")
            inst = ("global_string", _target, node.value)
            self.text.append(inst)
        else:
            # Create a new temporary variable name
            _target = self.new_temp()
            if _type == "int":
                node.value = int(node.value)
            # Make the SSA opcode and append to list of generated instructions
            inst = ("literal_" + _type, node.value, _target)
            self.current_block.append(inst)
        # Save the name of the temporary variable where the value was placed
        node.gen_location = _target

    def visit_Decl(self, node):
        # Store optional init val
        _init = node.init
        if not isinstance(node.type, ArrayDecl):
            self.visit(node.type)
            if _init is not None:
                self.visit(_init)
                _type = _init.uc_type.typename
                inst = (
                    "store_" + _type,
                    _init.gen_location,
                    node.type.gen_location,
                )
                self.current_block.append(inst)
            node.gen_location = node.type.gen_location
        else:
            if node.type.dim is not None or _init is not None:
                if node.type.dim is not None:
                    _dimensions = node.type.dim.value
                    node.type.dimensions = _dimensions
                    if hasattr(node.type, "type") and hasattr(node.type.type, "dim"):
                        node.type.dimensions = node.type.dimensions + "_" + node.type.type.dim.value
                    self.visit(node.type)
                else:
                    _dimensions = self._get_init_dimensions(_init)
                    _dimensions_join = '_'.join(_dimensions)
                    node.type.dimensions = _dimensions_join
                    node.init.dimensions = _dimensions_join
                    node.init.varname = node.name.name
                    self.visit(node.type)
                    self.visit(_init)
                    if isinstance(_init, Constant):
                        inst = ("store_char_" + node.init.dimensions, _init.gen_location, self.symtab.lookup(node.name.name))
                        self.current_block.append(inst)
            else:
                self.visit(node.type)



    def _get_init_dimensions(self, node):
        if hasattr(node, "exprs"):
            if hasattr(node.exprs[0], "exprs"):
                return [str(len(node.exprs)), str(len(node.exprs[0].exprs))]
            else:
                return [str(len(node.exprs))]
        return [str(len(node.value))]

    def visit_ExprList(self, node):
        for expression in node.exprs:
            self.visit(expression)

    def visit_InitList(self, node):
        if hasattr(node, "exprs"):
            _values = []
            if hasattr(node.exprs[0], "exprs"):
                _type = node.uc_type.type.type.typename
                for i in range(len(node.exprs)):
                    _values.append([])
                    for expression in node.exprs[i].exprs:
                        if _type == 'int':
                            _values[i].append(int(expression.value))
                        else:
                            _values[i].append(expression.value)
                _const_name = self.new_text("const_" + node.varname)
                inst = ("global_" + _type + "_" + node.dimensions, _const_name, _values)
                self.text.append(inst)
                inst = ("store_" + _type + "_" + node.dimensions, _const_name, self.symtab.lookup(node.varname))
                self.current_block.append(inst)
            else:
                _type = node.uc_type.type.typename
                for expression in node.exprs:
                    if _type == 'int':
                        _values.append(int(expression.value))
                    else:
                        _values.append(expression.value)
                _const_name = self.new_text("const_" + node.varname)
                inst = ("global_" + _type + "_" + node.dimensions, _const_name, _values)
                self.text.append(inst)
                inst = ("store_" + _type + "_" + node.dimensions, _const_name, self.symtab.lookup(node.varname))
                self.current_block.append(inst)




    def visit_For(self, node):
        # create new scope
        self.symtab.create_scope()

        # create blocks and set predecessors in advance (prevent errors)
        label_for_cond = self.new_label("for.cond")
        label_for_body = self.new_label("for.body")
        label_for_inc = self.new_label("for.inc")
        label_for_end = self.new_label("for.end")

        for_cond_block = ConditionBlock(label_for_cond[1:])
        for_body_block = BasicBlock(label_for_body[1:])
        for_inc_block = BasicBlock(label_for_inc[1:])
        for_end_block = BasicBlock(label_for_end[1:])

        for_cond_block.taken = for_body_block
        for_cond_block.fall_through = for_end_block

        # set closest loop in case a "break" occurs later
        self.current_loop = for_end_block

        self.visit(node.init)
        inst = ("jump", label_for_cond)
        self.current_block.append(inst)

        # for.cond block
        inst = (label_for_cond[1:] + ":",)
        for_cond_block.append(inst)
        self.current_block.branch = for_cond_block
        self.current_block.next_block = for_cond_block
        for_cond_block.predecessors.append(self.current_block)
        self.current_block = for_cond_block
        self.visit(node.cond)
        inst = ("cbranch", node.cond.gen_location, label_for_body, label_for_end)
        for_cond_block.append(inst)

        # for.body block
        inst = (label_for_body[1:] + ":",)
        for_body_block.append(inst)
        self.current_block = for_body_block
        self.current_block.predecessors.append(for_cond_block)
        for_cond_block.next_block = self.current_block
        self.visit(node.body)
        inst = ("jump", label_for_inc)
        self.current_block.append(inst)

        # for.inc block
        inst = (label_for_inc[1:] + ":",)
        for_inc_block.append(inst)
        for_inc_block.predecessors.append(self.current_block)
        self.current_block.next_block = for_inc_block
        self.current_block.branch = for_inc_block
        self.current_block = for_inc_block

        self.visit(node.next)
        inst = ("jump", label_for_cond)
        self.current_block.append(inst)
        self.current_block.branch = for_cond_block
        self.current_block.next_block = for_end_block

        # for.end block
        self.symtab.remove_scope()

        for_end_block.predecessors.append(for_cond_block)
        self.current_block = for_end_block
        inst = (label_for_end[1:] + ":",)
        self.current_block.append(inst)

    def visit_FuncCall(self, node):
        # load params into temps
        params_list = []
        if hasattr(node.args, 'exprs'):
            for arg in node.args.exprs:
                self.visit(arg)
                _type = arg.uc_type.typename
                _varname = arg.gen_location
                params_list.append((_type, _varname))
        else:
            self.visit(node.args)
            _type = node.args.uc_type.typename
            _varname = node.args.gen_location
            params_list.append((_type, _varname))

        # write params to call func
        for param in params_list:
            inst = ("param_" + param[0], param[1])
            self.current_block.append(inst)

        # add func call instruction
        _type = node.name.uc_type.type.typename
        _target = self.new_temp()
        inst = ("call_" + _type, "@" + node.name.name, _target)
        self.current_block.append(inst)

        node.gen_location = _target


    def visit_FuncDef(self, node):
        _name = node.decl.name.name
        node.cfg = BasicBlock(_name)
        self.fname = _name
        self.current_block = node.cfg
        label_return = self.new_label("exit")
        self.current_return = BasicBlock(label_return[1:])

        self.symtab.create_scope()

        self.visit(node.decl)
        self.visit(node.body)

        # creates return block
        self.current_block.branch = self.current_return
        self.current_block.next_block = self.current_return
        self.current_return.predecessors.append(self.current_block)
        self.current_block = self.current_return

        inst = (label_return[1:] + ":",)
        self.current_block.append(inst)
        _type = node.decl.type.type.uc_type.typename
        _target = self.new_temp()
        if _type != "void":
            inst = ("load_" + _type, "%return", _target)
            self.current_block.append(inst)
            inst = ("return_" + _type, _target)
        else:
            inst = ("return_void",)
        self.current_block.append(inst)
        
        self.symtab.remove_scope()

    def visit_FuncDecl(self, node):
        # create params list
        _params = []
        if node.params:
            _params = self._ParamList_gen_header(node.params)

        # function definition
        _type = node.type.uc_type.typename
        _name = node.type.declname.name
        inst = ("define_" + _type, "@" + _name, _params)
        self.current_block.append(inst)

        # "entry" label
        inst = ("entry:",)
        self.current_block.append(inst)

        # return temp
        if _type != "void":
            _varname = "%return"
            inst = ("alloc_" + _type, _varname)
            self.current_block.append(inst)

        # alloc params
        if node.params:
            self._ParamList_alloc(node.params, _params)

        node.gen_location = "%return"

    def visit_GlobalDecl(self, node):
        self.symtab.create_scope()
        for decl in node.decls:
            if isinstance(decl.type.uc_type, ArrayType):
                _type = decl.type.uc_type.type.typename
            else:
                _type = decl.type.uc_type.typename
            _name = "@" + decl.name.name
            self.symtab.add(decl.name.name, _name)
            if decl.init is not None:
                if hasattr(decl.init, "exprs"):
                    _init = []
                    for expression in decl.init.exprs:
                        if _type == "int":
                            _init.append(int(expression.value))
                        else:
                            _init.append(expression.value)
                    _dimensions = self._get_init_dimensions(decl.init)
                    _dimensions_join = '_'.join(_dimensions)
                    inst = ("global_" + _type + "_" + _dimensions_join, _name, _init)
                    self.text.append(inst)
                else:
                    _init = decl.init.value
                    if _type == "int":
                        _init = int(_init)
                    inst = ("global_" + _type, _name, _init)
                    self.text.append(inst)
            else:
                inst = ("global_" + _type, _name)
                self.text.append(inst)


    def visit_ID(self, node):
        _target = self.new_temp()
        _varname = self.symtab.lookup(node.name)
        _type = node.uc_type.typename
        inst = ("load_" + _type, _varname, _target)
        self.current_block.append(inst)

        node.gen_location = _target

    def visit_If(self, node):
        # create jump to if.cond block
        label_if_cond = self.new_label("if.cond")
        inst = ("jump", label_if_cond)
        self.current_block.append(inst)

        # creating blocks
        label_if_true = self.new_label("if.true")
        label_if_false = self.new_label("if.false")
        label_if_end = self.new_label("if.end")

        if_cond_block = ConditionBlock(label_if_cond[1:])
        if_true_block = BasicBlock(label_if_true[1:])
        if_false_block = BasicBlock(label_if_false[1:])
        if_end_block = BasicBlock(label_if_end[1:])

        # if.cond block
        self.current_block.next_block = if_cond_block
        self.current_block.branch = if_cond_block

        if_cond_block.predecessors.append(self.current_block)
        if_cond_block.taken = if_true_block
        if_cond_block.fall_through = if_false_block
        if_cond_block.next_block = if_true_block
        self.current_block = if_cond_block

        inst = (label_if_cond[1:] + ":",)
        self.current_block.append(inst)
        self.visit(node.cond)
        inst = ("cbranch", node.cond.gen_location, label_if_true, label_if_false)
        self.current_block.append(inst)

        # if.true block
        if_true_block.predecessors.append(self.current_block)
        inst = (label_if_true[1:] + ":",)
        if_true_block.append(inst)
        self.current_block = if_true_block

        self.visit(node.iftrue)

        inst = ("jump", label_if_end)
        self.current_block.append(inst)
        self.current_block.branch = if_end_block
        self.current_block.next_block = if_false_block

        # if.false block
        if_false_block.predecessors.append(if_cond_block)
        inst = (label_if_false[1:] + ":",)
        if_false_block.append(inst)
        self.current_block = if_false_block

        if node.iffalse != None:
            self.visit(node.iffalse)
        inst = ("jump", label_if_end)
        self.current_block.append(inst)
        self.current_block.branch = if_end_block
        self.current_block.next_block = if_end_block

        # if.end block
        if_end_block.predecessors.append(if_true_block)
        if_end_block.predecessors.append(if_false_block)
        inst = (label_if_end[1:] + ":",)
        if_end_block.append(inst)
        self.current_block = if_end_block

    def visit_ParamList(self, node):
        for param in node.params:
            self.visit(param)

    def visit_Print(self, node: Node):
        if node.expr is not None:
            if isinstance(node.expr, ExprList):
                for expression in node.expr.exprs:
                    self.visit(expression)
                    if isinstance(expression.uc_type, ArrayType):
                        if isinstance(expression.uc_type.type, ArrayType):
                            _type = expression.uc_type.type.type.typename
                        else:
                            _type = expression.uc_type.type.typename
                    else:
                        _type = expression.uc_type.typename
                    inst = ("print_" + _type, expression.gen_location)
                    self.current_block.append(inst)
            else:
                # Create the opcode and append to list
                self.visit(node.expr)
                if isinstance(node.expr.uc_type, ArrayType):
                    if isinstance(node.expr.uc_type.type, ArrayType):
                        _type = node.expr.uc_type.type.type.typename
                    else:
                        _type = node.expr.uc_type.type.typename
                else:
                    _type = node.expr.uc_type.typename
                inst = ("print_" + _type, node.expr.gen_location)
                self.current_block.append(inst)
        else:
            inst = ("print_void",)
            self.current_block.append(inst)
    def visit_Program(self, node: Node):
        # Visit all of the global declarations
        for _decl in node.gdecls:
            self.visit(_decl)
        # At the end of codegen, first init the self.code with
        # the list of global instructions allocated in self.text
        self.code = self.text.copy()
        # Also, copy the global instructions into the Program node
        node.text = self.text.copy()
        # After, visit all the function definitions and emit the
        # code stored inside basic blocks.
        for _decl in node.gdecls:
            if isinstance(_decl, FuncDef):
                # _decl.cfg contains the Control Flow Graph for the function
                # cfg points to start basic block
                bb = EmitBlocks()
                bb.visit(_decl.cfg)
                for _code in bb.code:
                    self.code.append(_code)

        if self.viewcfg:  # evaluate to True if -cfg flag is present in command line
            for _decl in node.gdecls:
                if isinstance(_decl, FuncDef):
                    dot = CFG(_decl.decl.name.name)
                    dot.view(_decl.cfg)  # _decl.cfg contains the CFG for the function

    def visit_Return(self, node):
        if node.expr:
            self.visit(node.expr)
            _type = node.expr.uc_type.typename
            _target = node.expr.gen_location
            inst = ("store_" + _type, _target, "%return")
            self.current_block.append(inst)

        inst = ("jump", "%" + self.current_return.label)
        self.current_block.append(inst)

    def visit_Type(self, node):
        pass

    def visit_ArrayDecl(self, node):
        if hasattr(node, "dimensions"):
            node.type.dimensions = node.dimensions
        self.visit(node.type)
    def visit_VarDecl(self, node: Node):
        # Allocate on stack memory
        _varname = node.declname.name
        _target = self.new_var(_varname)
        if hasattr(node, "dimensions"):
            self.dimtab[_target] = node.dimensions
        if hasattr(node, "dimensions") and node.dimensions is not None:
            inst = ("alloc_" + node.type.name + "_" + node.dimensions, _target)
        else:
            inst = ("alloc_" + node.type.name, _target)
        self.current_block.append(inst)
        node.gen_location = _target

    def visit_While(self, node):
        # create blocks and set predecessors in advance (prevent errors)
        label_while_cond = self.new_label("while.cond")
        label_while_body = self.new_label("while.body")
        label_while_end = self.new_label("while.end")

        while_cond_block = ConditionBlock(label_while_cond[1:])
        while_body_block = BasicBlock(label_while_body[1:])
        while_end_block = BasicBlock(label_while_end[1:])

        self.current_loop = while_end_block

        inst = ("jump", label_while_cond)
        self.current_block.append(inst)

        while_cond_block.taken = while_body_block
        while_cond_block.fall_through = while_end_block
        while_cond_block.next_block = while_body_block
        while_body_block.branch = while_cond_block
        while_body_block.next_block = while_end_block

        self.current_block.predecessors.append(while_cond_block)
        while_cond_block.predecessors.append(self.current_block)
        self.current_block.branch = while_cond_block
        self.current_block.next_block = while_cond_block
        self.current_block = while_cond_block

        inst = (label_while_cond[1:] + ":",)
        self.current_block.append(inst)
        self.visit(node.cond)
        inst = ("cbranch", node.cond.gen_location, label_while_body, label_while_end)
        self.current_block.append(inst)

        while_body_block.predecessors.append(self.current_block)
        self.current_block = while_body_block
        inst = (label_while_body[1:] + ":",)
        self.current_block.append(inst)
        self.visit(node.body)
        inst = ("jump", label_while_cond)
        self.current_block.append(inst)

        while_end_block.predecessors.append(self.current_block)
        self.current_block = while_end_block
        inst = (label_while_end[1:] + ":",)
        self.current_block.append(inst)


if __name__ == "__main__":

    # create argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "input_file",
        help="Path to file to be used to generate uCIR. By default, this script only runs the interpreter on the uCIR. \
              Use the other options for printing the uCIR, generating the CFG or for the debug mode.",
        type=str,
    )
    parser.add_argument(
        "--ir",
        help="Print uCIR generated from input_file.",
        action="store_true",
    )
    parser.add_argument(
        "--cfg", help="Show the cfg of the input_file.", action="store_true"
    )
    parser.add_argument(
        "--debug", help="Run interpreter in debug mode.", action="store_true"
    )
    args = parser.parse_args()

    print_ir = True
    create_cfg = True
    interpreter_debug = False

    # get input path
    input_file = args.input_file
    input_path = pathlib.Path(input_file)

    # check if file exists
    if not input_path.exists():
        print("Input", input_path, "not found", file=sys.stderr)
        sys.exit(1)

    # set error function
    p = UCParser()
    # open file and parse it
    with open(input_path) as f:
        ast = p.parse(f.read())

    ast.show(buf=sys.stdout, showcoord=True)
    sema = Visitor()
    sema.visit(ast)

    gen = CodeGenerator(create_cfg)
    gen.visit(ast)
    gencode = gen.code

    if print_ir:
        print("Generated uCIR: --------")
        gen.show()
        print("------------------------\n")

    vm = Interpreter(interpreter_debug)
    vm.run(gencode)
